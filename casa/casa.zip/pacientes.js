/* ══════════════════════════════════════════════════════════════════════
   LOS PACIENTES — refecho por pacientes.py el 2026.11.03-21:56:47
   No editar a mano el listado de ficheros: se rehace solo.
   Los nombres si se pueden escribir aqui — el script los conserva.
   ══════════════════════════════════════════════════════════════════════ */
var SF_PACIENTES = window.SF_PACIENTES = {
 "_doctrina": "Los pacientes y sus expedientes. Refecho por pacientes.py.\nUn navegador no puede listar una carpeta sin servidor: se lo decimos.\nUn directorio por matrícula: pacientes/<matricula>/<matricula>.sf",
 "version": "2026.11.03-21:56:47",
 "carpeta": "../pacientes/",
 "pacientes": [
  {
   "matricula": "APA0000",
   "nombre": "Ana",
   "sip": "00000000",
   "demo": true,
   "ficheros": [
    "APA0000.sf"
   ]
  },
  {
   "matricula": "DSF2026",
   "nombre": "DEMO SALU FOLIO",
   "sip": "0002026",
   "demo": false,
   "ficheros": [
    "_DSF2026.sf",
    "DSF2026_vacio.sf"
   ]
  },
  {
   "matricula": "JME8986",
   "nombre": "Joaquina",
   "sip": "11118986",
   "demo": false,
   "ficheros": [
    "JME8986.sf"
   ]
  },
  {
   "matricula": "PHG6618",
   "nombre": "Pierre Henri",
   "sip": "06076618",
   "demo": false,
   "ficheros": [
    "PHG6618.sf"
   ]
  }
 ]
};
